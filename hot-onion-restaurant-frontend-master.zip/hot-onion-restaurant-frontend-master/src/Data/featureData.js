const featureData = [
  {
    id: 401,
    title: "Fast Delivery",
    description:
      "Keep your system om sync with automated web hook based notification each time link is paid and how we dream about our future",
    icon: "https://i.ibb.co/1nz9kZH/bus.png",
    image: "https://i.ibb.co/55HN8q5/fast-delivery.png",
  },
  {
    id: 402,
    title: "A Good Auto Responder",
    description:
      "Keep your system om sync with automated web hook based notification each time link is paid and how we dream about our future",
    icon: "https://i.ibb.co/k1zY2Qr/notification.png",
    image: "https://i.ibb.co/j338hwk/chef-cook-food.png",
  },
  {
    id: 403,
    title: "Home Delivery",
    description:
      "Keep your system om sync with automated web hook based notification each time link is paid and how we dream about our future",
    image: "https://i.ibb.co/095tHyq/home-delivery.png",

    icon: "https://i.ibb.co/nb6vFyC/car.png",
  },
];
export default featureData;
