const firebaseConfig = {
  apiKey: "AIzaSyD6_py2yJADIwbw7DjrfFo6JCVNGfsiAR0",
  authDomain: "hot-onion-restaurant-frontend.firebaseapp.com",
  databaseURL: "https://hot-onion-restaurant-frontend.firebaseio.com",
  projectId: "hot-onion-restaurant-frontend",
  storageBucket: "hot-onion-restaurant-frontend.appspot.com",
  messagingSenderId: "596595858925",
  appId: "1:596595858925:web:068048b735b79ca074dbe4",
};
export default firebaseConfig;
